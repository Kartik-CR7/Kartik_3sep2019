create view V1 as
SELECT "ID","SAL","GENDER" FROM TAB1
/

