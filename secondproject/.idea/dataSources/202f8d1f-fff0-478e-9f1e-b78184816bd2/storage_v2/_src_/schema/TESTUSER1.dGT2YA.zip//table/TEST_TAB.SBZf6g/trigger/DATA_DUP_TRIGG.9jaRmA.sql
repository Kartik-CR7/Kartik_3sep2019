create trigger DATA_DUP_TRIGG
    before insert
    on TEST_TAB
    for each row
DECLARE
  PRAGMA AUTONOMOUS_TRANSACTION; 
  EID1 NUMBER;
  BEGIN
       SELECT COUNT(*) INTO EID1 
       FROM TEST_TAB  WHERE EID = :NEW.EID;
       IF EID1 > 0 THEN
          RAISE_APPLICATION_ERROR(-20001,'Duplicate value arriese');
       END IF;
       COMMIT;
  END;
/

