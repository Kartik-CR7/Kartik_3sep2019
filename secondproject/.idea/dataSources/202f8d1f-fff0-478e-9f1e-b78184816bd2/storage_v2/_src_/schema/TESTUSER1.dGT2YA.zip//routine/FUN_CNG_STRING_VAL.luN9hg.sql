create FUNCTION FUN_CNG_STRING_VAL(V_template_str VARCHAR2,
                                              V_value_str    VARCHAR2)
  RETURN VARCHAR2 AS
  V_COUNT     NUMBER;
  V_VALUE1    VARCHAR2(1000);
  V_VALUE2    VARCHAR2(1000);
  V_TEMP      VARCHAR2(2000);
  V_RET_VALUE VARCHAR2(2000);
BEGIN
  V_COUNT := 0;
  V_TEMP  := V_template_str;
  V_COUNT := REGEXP_COUNT(V_value_str, '{"', 1, 'i');
  dbms_output.put_line('V_COUNT' || ' ' || V_COUNT);
  FOR I IN 1 .. V_COUNT LOOP
    V_VALUE1 := SUBSTR(V_value_str,
                       INSTR(V_value_str, '{"', 1, I),
                       ((INSTR(V_value_str, '"}', 1, I) + 2) -
                       INSTR(V_value_str, '{"', 1, I)));
    IF I = V_COUNT THEN
      V_VALUE2 := SUBSTR(V_value_str, INSTR(V_value_str, '"}', 1, I) + 2);
    ELSIF I < V_COUNT THEN
      V_VALUE2 := SUBSTR(V_value_str,
                         INSTR(V_value_str, '"}', 1, I) + 2,
                         INSTR(V_value_str, '{"', 1, I + 1) -
                         (INSTR(V_value_str, '"}', 1, I) + 2));
    END IF;
    DBMS_OUTPUT.PUT_LINE('V_VALUE1' || ' ' || V_VALUE1);
    DBMS_OUTPUT.PUT_LINE('V_VALUE2' || ' ' || V_VALUE2);
    V_RET_VALUE := REPLACE(V_TEMP, V_VALUE1, V_VALUE2);
    V_TEMP      := V_RET_VALUE;
  END LOOP;
  V_RET_VALUE := REGEXP_REPLACE(V_TEMP, '{(.+?)}', '<<not found>>');
  RETURN V_RET_VALUE;
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM);
    RETURN SQLERRM;
END FUN_CNG_STRING_VAL;
/

