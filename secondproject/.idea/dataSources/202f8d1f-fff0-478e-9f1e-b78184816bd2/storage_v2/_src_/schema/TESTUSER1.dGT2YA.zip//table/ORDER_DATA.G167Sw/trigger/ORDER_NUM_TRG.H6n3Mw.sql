create trigger ORDER_NUM_TRG
    before insert
    on ORDER_DATA
    for each row
BEGIN
  SELECT order_seq.NEXTVAL
  INTO   :new.ORDERID
  FROM   dual;
END;
/

