create trigger CHECK_STU
    before insert or update of ID
    on STU
    for each row
declare
var number
begin
select count(*) into var from stu where id=:new.id;
if var<>0 then
--raise_application_error(-20100,'error');
dbms_output.put_line(var);
end if;
dbms_output.put_line(var);
end;
/

