create trigger DUP_VALUE
    before insert
    on EMPLT_VW
    for each row
DECLARE
  --PRAGMA AUTONOMOUS_TRANSACTION;
  E_ID NUMBER;
  BEGIN
       SELECT COUNT(*) 
       INTO E_ID 
       FROM EMPLT_VW 
       WHERE EID = :NEW.EID;
       IF E_ID > 0 THEN
          DBMS_OUTPUT.PUT_LINE(E_ID);
          RAISE_APPLICATION_ERROR(-20001,'Duplicate value');
       END IF;
  END;
/

